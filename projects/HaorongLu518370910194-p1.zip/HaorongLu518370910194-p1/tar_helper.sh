#!/bin/bash

tar -zcvf p1.tar.gz *
mv p1.tar.gz /mnt/d/学习/VE482/Project/P1