//
// Created by ancientmodern on 2021/9/17.
//

#include "mumsh.h"

void sigint_handler(int sig_num) {
    if (sig_num) {
        printf("\n");
    }
    if (!is_running_sub) {
        siglongjmp(env, 42);
    }
}

int main() {
    char *line = (char *) malloc(sizeof(char) * MAX_LINE);
    char *conjLine = (char *) malloc(sizeof(char) * MAX_LINE);
    memset(line, 0, MAX_LINE);
    redirect_t tmp_re;
    int jobs_num = 0;
    char **jobs_name = (char **) malloc(sizeof(char *) * MAX_LINE);
    int *jobs_pid = (int *) malloc(sizeof(int) * MAX_LINE);
    for (int i = 0; i < MAX_LINE; i++) {
        jobs_name[i] = NULL;
    }
    memset(jobs_pid, 0, MAX_LINE);

    // signal handling
    struct sigaction s;
    s.sa_handler = sigint_handler;
    sigemptyset(&s.sa_mask);
    s.sa_flags = SA_RESTART;
    sigaction(SIGINT, &s, NULL);

    while (1) {
        sigsetjmp(env, 1);
        is_running_sub = false;
        memset(conjLine, 0, MAX_LINE);

        prompt("mumsh $ ");
        if (fgets(line, MAX_LINE, stdin) != NULL) { // Not Ctrl D
            if (strlen(line) <= 1) { // Only "\n"
                continue;
            }
            line[strlen(line) - 1] = '\0';
            strcat(conjLine, line);

            argv_t *info = (argv_t *) malloc(sizeof(argv_t));
            char *real_line = (char *) malloc(sizeof(char) * MAX_LINE);
            char **argv = (char **) malloc(sizeof(char *) * MAX_LINE);
            readInput(line, info, real_line, argv);

            while (info->single_quote != -1 || info->double_quote != -1 || !strcmp(argv[info->length - 1], "<") ||
                   !strcmp(argv[info->length - 1], ">") || !strcmp(argv[info->length - 1], "|")) {
                prompt("> ");
                if (fgets(line, MAX_LINE, stdin) != NULL) {
                    if (strlen(line) <= 1) {
                        continue;
                    }
                    line[strlen(line) - 1] = '\0';
                    if (info->single_quote != -1 || info->double_quote != -1) {
                        conjLine[strlen(conjLine)] = '\n';
                    } else if (!strcmp(argv[info->length - 1], "|")) {
                        conjLine[strlen(conjLine)] = ' ';
                    }
                    strcat(conjLine, line);
                    strcpy(line, conjLine);
                    readInput(line, info, real_line, argv);
                } else {
                    // Ctrl D
                    printf("exit\n");
                    free(line);
                    free(conjLine);
                    for (int j = 0; j < jobs_num; ++j) {
                        free(jobs_name[j]);
                    }
                    free(jobs_name);
                    free(jobs_pid);
                    exit(0);
                }
            }

            bool isBackground = !strcmp(argv[info->length - 1], "&");
            if (isBackground) {
                jobs_name[jobs_num] = (char *) malloc(sizeof(char) * (strlen(conjLine) + 8));
                strcpy(jobs_name[jobs_num++], conjLine);
                argv[info->length - 1] = NULL;
                info->length--;
            }

            is_running_sub = true;

            if (!built_in_cd(argv) || !built_in_jobs(argv, jobs_num, jobs_name, jobs_pid)) {
                free(real_line);
                free(argv);
                free(info);
                continue;
            }

            int pipe_index = -1;
            bool finish = false;
            pid_t pid;
            int in = 0, fd[2];

            while (!finish) {
                memset(fd, 0, 2);
                char **this_argv = (char **) malloc(sizeof(char *) * MAX_LINE);
                char **real_argv = (char **) malloc(sizeof(char *) * MAX_LINE);
                for (int i = 0; i < MAX_LINE; i++) {
                    this_argv[i] = NULL;
                    real_argv[i] = NULL;
                }

                int count = 0;
                bool after_pipe = (pipe_index != -1);
                for (int j = pipe_index + 1; j < info->length; ++j) {
                    if (!strcmp(argv[j], "|")) {
                        pipe_index = j;
                        break;
                    } else if (!strcmp(argv[j], "\\|")) {
                        this_argv[count++] = "|";
                    } else {
                        this_argv[count++] = argv[j];
                    }
                    if (j == info->length - 1) {
                        finish = true;
                    }
                }

                if (parse_redirect(&tmp_re, this_argv, count, after_pipe, finish)) {
                    free(this_argv);
                    free(real_argv);
                    break;
                }

                for (int j = 0, k = 0; j < count; ++j) {
                    if (!strcmp(this_argv[j], "\\<")) {
                        real_argv[k++] = "<";
                    } else if (!strcmp(this_argv[j], "\\>")) {
                        real_argv[k++] = ">";
                    } else if (!strcmp(this_argv[j], "\\>\\>")) {
                        real_argv[k++] = ">>";
                    } else if (is_not_redirection(this_argv, j)) {
                        real_argv[k++] = this_argv[j];
                    }
                }

                pipe(fd);
                pid = fork(); // fork a child process
                if (pid < 0) {
                    printf("ERROR: forking child process failed\n");
                    exit(1);
                } else if (pid == 0) { // child process
                    // signal(SIGINT, SIG_DFL);
                    if (in != 0) {
                        dup2(in, 0);
                        close(in);
                    }
                    if (!finish && fd[1] != 1) {
                        dup2(fd[1], 1);
                        close(fd[1]);
                    }
                    redirect_fd(&tmp_re);

                    if (!strcmp(real_argv[0], "pwd")) {
                        built_in_pwd();
                    } else {
                        if (execvp(real_argv[0], real_argv) < 0) {
                            printf("%s: command not found\n", real_argv[0]);
                            exit(1);
                        }
                    }
                } else { // parent process
                    // close(fd[0]);
                    if (isBackground && finish) {
                        jobs_pid[jobs_num - 1] = pid;
                        printf("[%d] %s\n", jobs_num, conjLine);
                        waitpid(pid, NULL, WNOHANG);
                    }
                }
                close(fd[1]);
                in = fd[0];

                free(this_argv);
                free(real_argv);
            }
            if (!isBackground) {
                while (wait(NULL) != -1);
            }
            free(real_line);
            free(argv);
            free(info);
        } else {
            // Ctrl D
            printf("exit\n");
            free(line);
            free(conjLine);
            for (int j = 0; j < jobs_num; ++j) {
                free(jobs_name[j]);
            }
            free(jobs_name);
            free(jobs_pid);
            exit(0);
        }
    }

    free(line);
    free(conjLine);
    for (int j = 0; j < jobs_num; ++j) {
        free(jobs_name[j]);
    }
    free(jobs_name);
    free(jobs_pid);
}
